Command Line Argument To Execute The C Programming Project02 For Source to HTML Conversion

Command to run all the .c files: gcc *.c      
Command to Run Source2HTML Conversion: /a.out test.c
or
Command to Run Source2HTML Conversion: /a.out test.txt

Note: Run any one command to of conversion

This will give the required output
