/* 
    this is multi-line comment 
    Name: Indrajith
    Date: 28-Oct-2024
    Description: Program to find the sum of 2 integer number
*/

/*

#include <stdio.h>


int main()
{
    int sum, num1, num2;
    printf("Enter the 1st Number: ");
    scanf("%d", &num1);

    printf("Enter the 2nd Number: ");
    scanf("%d", &num2);

    sum = num1 + num2;

    printf("The Sum of numbers is: %d\n",sum);

    return 0;
}

*/
